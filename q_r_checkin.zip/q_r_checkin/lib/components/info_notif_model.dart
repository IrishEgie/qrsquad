import '/flutter_flow/flutter_flow_util.dart';
import 'info_notif_widget.dart' show InfoNotifWidget;
import 'package:flutter/material.dart';

class InfoNotifModel extends FlutterFlowModel<InfoNotifWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
