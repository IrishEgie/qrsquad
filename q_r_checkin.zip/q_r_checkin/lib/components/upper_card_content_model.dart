import '/flutter_flow/flutter_flow_util.dart';
import 'upper_card_content_widget.dart' show UpperCardContentWidget;
import 'package:flutter/material.dart';

class UpperCardContentModel extends FlutterFlowModel<UpperCardContentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
