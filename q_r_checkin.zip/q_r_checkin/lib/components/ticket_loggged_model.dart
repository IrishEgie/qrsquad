import '/flutter_flow/flutter_flow_util.dart';
import 'ticket_loggged_widget.dart' show TicketLogggedWidget;
import 'package:flutter/material.dart';

class TicketLogggedModel extends FlutterFlowModel<TicketLogggedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
