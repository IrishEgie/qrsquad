import '/flutter_flow/flutter_flow_util.dart';
import 'ticket_log_widget.dart' show TicketLogWidget;
import 'package:flutter/material.dart';

class TicketLogModel extends FlutterFlowModel<TicketLogWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
