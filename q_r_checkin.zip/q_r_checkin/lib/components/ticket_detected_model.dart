import '/flutter_flow/flutter_flow_util.dart';
import 'ticket_detected_widget.dart' show TicketDetectedWidget;
import 'package:flutter/material.dart';

class TicketDetectedModel extends FlutterFlowModel<TicketDetectedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
