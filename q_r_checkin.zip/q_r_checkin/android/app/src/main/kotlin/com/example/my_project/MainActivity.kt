package com.mycompany.qrcheckin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
